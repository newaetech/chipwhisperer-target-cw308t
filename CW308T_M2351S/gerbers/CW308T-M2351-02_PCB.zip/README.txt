2-Layer PCB

Soldermask: *
Silkscreen: White

Finish: *

Individual PCB Size: 52.3mm x 64.6mm

Board Files:

 .GTO - Top Silkscreen
 .GTS - Top Soldermask
 .GTL - Top Copper
 .GBL - Bottom Copper
 .GBS - Bottom Soldermask
 .GBO - Bottom Silkscreen
 .GM1 - Outline of Board
 .NCDRILL - Drill Files


Other Files:

 .GTP - Top Paste (used for stencil)
 .GBP - Bottom Paste (NOT USED)