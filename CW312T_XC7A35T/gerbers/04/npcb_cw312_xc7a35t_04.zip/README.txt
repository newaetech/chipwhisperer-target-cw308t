
GENERAL
----------
Board Size: 58.7 mm x 53.7 mm
Finish: Lead-Free (such as HASL, Immersion Gold, Immersion Silver)
Soldermask: Any
Silkscreen: White
Board Thickness: 1.6mm

Min drill = 0.2mm
Space/Trace = 5mil

PCB STACKUP:
--------------------------------
 .GTO Top Silkcreen
 .GTS Top Soldermask
 .GTL TOP COPPER               (LAYER 1)
 .GP1 INNER PLANE              (LAYER 2)
 .G1  INNER LAYER              (LAYER 3)
 .GBL BOTTOM COPPER            (LAYER 4)
 .GTS Bottom Soldermask 
 .GBO Bottom Silkscreen

ADDITIONAL FILES:
--------------------------------
 .NCDRILL - NC Drill
 .GTP Top Stencil
 .GBP Bottom Stencil
 .GM1 Milling Layer

BOARD CONSTRUCTION
--------------------------------
Standard board stackup spacing for 4-layer 0.062" PCB

