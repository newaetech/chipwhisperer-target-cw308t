2-Layer PCB

Soldermask: Blue
Silkscreen: White

Finish: Immersion Gold

Individual PCB Size: 52.3mm x 64.6mm
Panel Size: 138.78 mm x 114.27 mm

Panelized with VSCORE (in file .GM18)

Board Files:

 .GTO - Top Silkscreen
 .GTS - Top Soldermask
 .GTL - Top Copper
 .GBL - Bottom Copper
 .GBS - Bottom Soldermask
 .GBO - Bottom Silkscreen
 .GM1 - Panel Outline
 .GM18 - VSCORE for Panel
 .NCDRILL - Drill File


Other Files:

 .GTP - Top Paste (used for stencil)
 .GBP - Bottom Paste (NOT USED)