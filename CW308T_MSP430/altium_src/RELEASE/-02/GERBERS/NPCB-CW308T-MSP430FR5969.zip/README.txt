
GENERAL
----------
Board Size: 52.3 mm x 67 mm
Finish: Immersion Gold (ENIG) 
Soldermask: Blue
Silkscreen: White
Board Thickness: 1.6mm

Min drill = 0.3mm
Space/Trace = 6mil

PCB STACKUP:
--------------------------------
 .GTO Top Silkcreen
 .GTS Top Soldermask
 .GTL TOP COPPER       (LAYER 1)
 .GBL BOTTOM COPPER    (LAYER 2)
 .GTS Bottom Soldermask
 .GBO Bottom Silkscreen

ADDITIONAL FILES:
--------------------------------
 .NCDRILL - NC Drill
 .GTP Top Stencil
 .GBP Bottom Stencil
 .GM1 Milling Layer

BOARD CONSTRUCTION
--------------------------------
Standard board stackup spacing for 2-layer 0.062" PCB ok


E-TEST
------

PCBs must be 100% electrically tested.