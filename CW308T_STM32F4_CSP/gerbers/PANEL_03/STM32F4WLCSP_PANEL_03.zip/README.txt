2-Layer PCB

Soldermask: Blue
Silkscreen: White

Finish: Immersion Gold

4 mil trace/space

Individual PCB Size: 54.6mm x 65.7mm
Panel Size: 140.77mm x 119.63mm
Panelized with VSCORE (in file .GM18)

Board Files:

 .GTO - Top Silkscreen
 .GTS - Top Soldermask
 .GTL - Top Copper
 .GBL - Bottom Copper
 .GBS - Bottom Soldermask
 .GBO - Bottom Silkscreen
 .GM1 - Panel Outline
 .GM18 - VSCORE for Panel
 .NCDRILL - Drill File


Other Files:

 .GTP - Top Paste (NOT USED)
 .GBP - Bottom Paste (used for stencil)